package moviedam.debate;

public class ChanbanlikeDataBean {
	private int cb_like_id;
	private int cb_id;
	private String mem_id;
	private String cb_like_type;
	
	public int getCb_like_id() {
		return cb_like_id;
	}
	public void setCb_like_id(int cb_like_id) {
		this.cb_like_id = cb_like_id;
	}
	public int getCb_id() {
		return cb_id;
	}
	public void setCb_id(int cb_id) {
		this.cb_id = cb_id;
	}
	public String getMem_id() {
		return mem_id;
	}
	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}
	public String getCb_like_type() {
		return cb_like_type;
	}
	public void setLike_type(String cb_like_type) {
		this.cb_like_type = cb_like_type;
	}
	
}
