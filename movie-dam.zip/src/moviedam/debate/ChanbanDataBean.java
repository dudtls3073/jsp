package moviedam.debate;
import java.sql.Timestamp;

public class ChanbanDataBean {
	private int cb_id; 
    private String cb_writer;
    private String cb_title;
    private String cb_content;
    private Timestamp reg_date;
    private int cb_hits; //조회수
    private String cb_file;
    
    
	public int getCb_id() {
		return cb_id;
	}
	public void setCb_id(int cb_id) {
		this.cb_id = cb_id;
	}
	
	public String getCb_writer() {
		return cb_writer;
	}
	public void setCb_writer(String cb_writer) {
		this.cb_writer = cb_writer;
	}
	
	public String getCb_title() {
		return cb_title;
	}
	public void setCb_title(String cb_title) {
		this.cb_title = cb_title;
	}
	
	public String getCb_content() {
		return cb_content;
	}
	public void setCb_content(String cb_content) {
		this.cb_content = cb_content;
	}
	
	public Timestamp getReg_date() {
		return reg_date;
	}
	public void setReg_date(Timestamp reg_date) {
		this.reg_date = reg_date;
	}
	
	public int getCb_hits() {
		return cb_hits;
	}
	public void setCb_hits(int cb_hits) {
		this.cb_hits = cb_hits;
	}
	
	public String getCb_file() {
		return cb_file;
	}
	public void setCb_file(String cb_file) {
		this.cb_file = cb_file;
	}
 
 
	
}